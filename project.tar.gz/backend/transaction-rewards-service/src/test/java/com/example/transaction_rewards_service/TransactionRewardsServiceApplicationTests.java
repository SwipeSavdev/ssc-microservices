package com.example.transaction_rewards_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionRewardsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
