package com.example.account_card_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountCardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountCardServiceApplication.class, args);
	}

}
